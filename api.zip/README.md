# apiecomersnodejs

Es ta acontinuacion del la aplicacion realizada en fllutter de ecomers, con la diferencia que este es la api res

# Peticcion de acceso

Para poder hacer una peticion de acceso se tendra que usar la ruta
http://localhost:9000/tokeniser/ el cual dara como respuesta que :
